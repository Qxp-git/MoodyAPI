Moody tutorial T2a
=================
Model scale soft mooring. Three catenary chains attached to a cylindrical buoy. 
Only moorings are simulated, using .  


Run from command line
---------------------
source ../../etc/bashrcMoody 
moody.x -f mooringSystem.m -o moodyResults
python post.py

Python post-processing dependencies are matplotlib and numpy.

Run from Matlab
---------------
Start matlab and execute runFromMatlab.m



